import request from '@/utils/request'

export function getMenu(data) {
  return request({
    url: '/v1/menu/load',
    method: 'post',
    data
  })
}

export function getMenuFunctions() {
  return request({
    url: '/v1/menuFunction/query',
    method: 'post'
  })
}
