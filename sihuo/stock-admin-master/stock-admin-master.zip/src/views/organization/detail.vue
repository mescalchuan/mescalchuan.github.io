<template>
  <div class="detail-page">
    <back></back>
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span>编号： {{ basicInfo.index }}</span>
        <span>组织代码: {{ basicInfo.code }}</span>
        <span>组织名称: {{ basicInfo.name }}</span>
        <span>法人: {{ basicInfo.represent }}</span>
      </div>
      <div style="padding: 10px">
        <el-row :gutter="20">
          <el-col :span="18">
            <el-table
              header-cell-class-name="table-header-color"
              :data="assetData"
              border
              style="width: 100%"
            >
              <el-table-column
                prop="totlaAsset"
                label="总资产"
              />
              <el-table-column
                prop="shareHolder"
                label="股东数"
              />
              <el-table-column
                prop="stockTotal"
                label="股权总数"
              />
              <el-table-column
                prop="stockTotalPrice"
                label="股权总价"
              />
              <el-table-column
                prop="groupStockCount"
                label="集体持股总数"
              />
              <el-table-column
                prop="groupStockPrice"
                label="集体持股总价"
              />
              <el-table-column
                prop="perStockPrice"
                label="每股作价"
              />
            </el-table>
          </el-col>
          <el-col :span="6">
            <el-table
              header-cell-class-name="table-header-color"
              :data="stockRightData"
              border
              style="width: 100%"
            >
              <el-table-column
                prop="type"
                label="股权类型"
              />
              <el-table-column
                prop="price"
                label="股权系数"
              />
            </el-table>
          </el-col>
        </el-row>
      </div>
    </el-card>
    <el-card class="box-card">
      <div slot="header" class="clearfix">经济组织设置</div>
      <div>
        <form-item-layout label="总资产设置">
          <el-input v-model="form.total"></el-input>
        </form-item-layout>
        <div v-for="(item, index) in form.distribute" class="form-group">
          <form-item-layout label="总资产设置" required class="form-item-width">
            <el-select v-model="item.type" placeholder="请选择" class="width-200">
              <el-option
                v-for="option in typeList"
                :key="option.value"
                :label="option.label"
                :value="option.value">
              </el-option>
            </el-select>
          </form-item-layout>
          <form-item-layout label="总资产设置">
            <el-input v-model="item.coefficient" class="width-200"></el-input>
          </form-item-layout>
          <el-button @click="deleteParam(index)" :disabled="form.distribute.length === 1" type="danger" class="add-btn"  icon="el-icon-delete">减少股权种类</el-button>
          <el-button v-if="index === form.distribute.length - 1" @click="addParam" type="primary" icon="el-icon-edit">新增股权种类</el-button>
        </div>
      </div>
      <el-button type="primary" style="width: 100%;margin-top: 40px">确认变更</el-button>
    </el-card>
  </div>
</template>

<script>
import FormItemLayout from '../../components/FormItemLayout'
import Back from '../../components/Back'
export default {
  name: 'OrganizationDetail',
  components: {
    FormItemLayout,
    Back
  },
  data() {
    return {
      tableData: [
        {
          index: 1,
          code: 12,
          name: 'zhanah',
          represent: 'sdasas',
          address: 'lallallal',
          createdDate: '2018-09-29'
        }
      ],
      basicInfo: {
        index: 1,
        code: '323232',
        name: '张家口',
        represent: '酷酷酷'
      },
      assetData: [
        {
          totlaAsset: 78999999,
          shareHolder: 222,
          stockTotal: 56454,
          stockTotalPrice: 56454,
          groupStockCount: 4343,
          groupStockPrice: 6343,
          perStockPrice: 322
        }
      ],
      stockRightData: [
        {
          type: '贡献股',
          price: '1.0'
        },
        {
          type: '贡献股',
          price: '1.0'
        },
        {
          type: '爱新股',
          price: '1.0'
        }
      ],
      form: {
        total: 1222,
        distribute: [
          {
            type: '',
            coefficient: 1.0
          }
        ]
      },
      typeList: [
        {
          label: 'kakkak',
          value: 'ssss'
        }
      ]
    }
  },
  methods: {
    addParam() {
      let temp = {
        type: '',
        coefficient: 1.0
      }
      this.form.distribute.push(temp)
    },
    deleteParam(index) {
      this.form.distribute.splice(index, 1)
    }
  }
}
</script>

<style lang="scss" scoped>
.detail-page {
  width: 100%;
  padding: 10px;
  background: rgb(235,238,242);
  min-height: calc(100vh - 50px);

  .content {
    background: #fff;
    padding: 20px;
    margin-top: 15px;
  }

  .box-card {
    margin-top: 10px;
    .clearfix {
      span {
        font-size: 14px;
        font-weight: 600;
        display: inline-block;
        margin-right: 20px;
      }
    }
  }

  .form-group {
    display: flex;
    justify-content: flex-start;
    margin-top: 30px;

    .width-200 {
      width: 200px;
    }

    .add-btn {
      margin: 0 0 0 20px;
    }
  }
  .form-item-width {
    width: 40%;
    max-width: 400px;
  }
}
</style>

<style>
  .table-header-color {
    background: rgb(245,247,250)!important;
  }
</style>
