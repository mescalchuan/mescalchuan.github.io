<template>
  <div class="page-container">
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span>用户组管理</span>
      </div>
      <div class="main">
        <el-button
          class="el-icon-plus"
          type="primary"
          style="margin-bottom: 5px"
          @click="addGroup"
        >新增用户组</el-button>
        <el-table :data="tableData" border style="width: 100%" header-cell-class-name="table-header-color">
          <el-table-column prop="accountGroupName" label="用户组名称" min-width="25%" />
          <el-table-column prop="accountGroupDescription" label="用户组备注" min-width="55%" />
          <el-table-column label="操作" min-width="20%">
            <template slot-scope="scope">
              <el-button
                type="text"
                size="small"
                class="el-icon-setting"
                @click="handleClick(scope.row)"
                :disabled="scope.row.accountGroupId === 1"
              >变更</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-card>
  </div>
</template>

<script>
export default {
  data() {
    return {}
  },
  computed: {
    tableData() {
      return this.$store.state.account.accountGroupList
    }
  },
  created() {
    this.$store.dispatch('getAccountGroup')
  },
  methods: {
    handleClick(row) {
      console.log(row)
      this.$router.push({
        path: '/account/groupAdminAdd',
        query: {
          accountGroupId: row.accountGroupId
        }
      })
    },
    addGroup() {
      this.$router.push('/account/groupAdminAdd')
    }
  }
}
</script>

<style scoped>
.page-container {
  padding: 0;
  margin: 10px;
}

.box-card {
  margin-top: 10px;
}

.main {
  padding: 10px;
}
</style>

<style>
.box-card .el-card__body {
  padding: 10px 0;
}
</style>
<style>
  .table-header-color {
    background: rgb(245,247,250)!important;
  }
</style>
