<template>
  <edit-account is-module/>
</template>

<script>
import editAccount from '@/views/account/editAccount'
export default {
  components: {
    editAccount
  }
}
</script>