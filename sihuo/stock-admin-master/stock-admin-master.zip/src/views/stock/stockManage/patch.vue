<template>
  <div class="patch-page">
     <back></back>
    <div class="patch-content">
      <div>
        <input type="file" ref="file">
      </div>
      <el-button type="primary" style="margin-top: 20px;" @click="upload">上传<i class="el-icon-upload el-icon--right"></i></el-button>
      <el-divider></el-divider>
      <div>
        <h3>导入数据表结构说明：</h3>
        <p>1、批量入股前必须保证当前农户已经录入系统</p>
        <p>2、批量入股前请先增加经济组织，并按数据表配置股权种类及对应系数</p>
        <p>3、待导入Excel表的扩展名必须为xls，且结构如下（期中从第I列开始为股权种类名称，股权种类数量不限，总股放在最后面）：</p>
        <img :src="require('../../../assets/patch.png')" alt="" style="width: 100%;">
      </div>
    </div>
  </div>
</template>

<script>
import { importExcel } from '@/api/import'
import Back from '../../../components/Back'
export default {
  components: {
    Back
  },
  data() {
    return {
      form: {}
    }
  },
  methods: {
    areaChange(val) {
      console.log(val)
      this.areaList = val
      this.form.villageGroupId = val[1].value
    },
    upload() {
      console.log(this.$refs)
      console.log(this.$refs.file.files)
      if(this.$refs.file.files.length) {
        this.$confirm(`当前即将导入${this.areaList[1].name}农户信息`, '系统提示', {
          confirmButtonText: '确认上传',
          cancelButtonText: '取消'
        }).then(action => {
            let fd = new FormData()
            fd.append('file', this.$refs.file.files[0])
            fd.append('villageId', this.areaList[1].value)
            let m = this.$message({
              message: '正在上传...',
              duration: 0
            });
            importExcel(fd).then(res => {
              m.close()
              this.$message({
                message: '操作成功',
                type: 'success'
              })
            }).catch(e => {
              m.close()
            })
            // this.$message({
            //   type: 'info',
            //   message: `action: ${ action }`
            // });
          }
        ).catch(() => {})
      }
      else {
        this.$message({
          type: 'warning',
          message: '请选择文件'
        })
      }
    }
  }
}
</script>

<style scope>
   .patch-page {
    width: 100%;
    padding: 10px;
  }

  .patch-content {
    background: #fff;
    padding: 20px;
  }
</style>