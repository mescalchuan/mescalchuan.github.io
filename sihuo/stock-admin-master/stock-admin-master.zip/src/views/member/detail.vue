<template>
  <div class="detail-page">
    <back></back>
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        {{basicInfo.address}} 户 {{basicInfo.familyNo}} ({{basicInfo.name}})
        <el-button icon="el-icon-plus" type="primary" @click="addMember" style="float: right">新增家庭成员</el-button>
      </div>
      <div style="padding: 10px">
        <el-table
          header-cell-class-name="table-header-color"
          :data="tableData"
          border
          style="width: 100%"
        >
          <el-table-column
            prop="memberName"
            label="成员"
          />
          <el-table-column
            prop="relationship"
            label="与户主关系"
          >
            <template slot-scope="scope">
              <p v-if="relationshipList.length">{{ relationshipList.filter(item => item.relationshipId == scope.row.relationship)[0].relationshipName }}</p>
            </template>
          </el-table-column>
          <el-table-column
            prop="sex"
            label="性别"
          >
            <template slot-scope="scope">
              <p v-if="scope.row.sex == 0">保密</p>
              <p v-else-if="scope.row.sex == 1">男</p>
              <p v-else-if="scope.row.sex == 2">女</p>
            </template>
          </el-table-column>
          <el-table-column
            prop="idCard"
            label="身份证号"
            width="230"
          />
          <el-table-column
            prop="birthDate"
            label="出生日期"
          />
          <el-table-column
            prop="currentAddress"
            label="现居住地"
          />
          <el-table-column
            fixed="right"
            label="操作"
            width="150"
          >
            <template slot-scope="scope">
              <el-button type="text" size="small" @click="handleEdit('editMember', scope.row.memberId)">变更</el-button>
              <el-button type="text" size="small" @click="handleEdit('detail', scope.row.memberId)">详情</el-button>
              <el-button type="text" size="small" @click="deleteMember(scope.row)">注销</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-card>
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        {{basicInfo.address}} 户 {{basicInfo.familyNo}} ({{basicInfo.name}})
        <el-tag type="success" size="mini">变更记录</el-tag>
      </div>
    </el-card>
    <el-dialog
      title="关系变更"
      :visible.sync="dialogVisible"
      width="30%">
      <el-form label-width="80px">
        <el-form-item v-for="(item, index) in tableData" :key="item.memberId" :label="item.memberName">
          <el-select v-model="form[index]" filterable placeholder="更新关系">
            <el-option
              v-for="item in relationshipList"
              :key="item.relationshipId"
              :label="item.relationshipName"
              :value="item.relationshipId"
            />
          </el-select>
        </el-form-item>
      </el-form>
    <el-button @click="dialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="makeSureCancle(form)">确 定</el-button>
  </span>
    </el-dialog>
  </div>
</template>

<script>
import FormItemLayout from '../../components/FormItemLayout'
import Back from '../../components/Back'
import { familyMember, cancelMember, memberRelationship } from '../../api/member'

export default {
  name: 'OrganizationDetail',
  components: {
    FormItemLayout,
    Back
  },
  data() {
    return {
      tableData: [
        {
          index: 1,
          code: 12,
          name: 'zhanah',
          represent: 'sdasas',
          address: 'lallallal',
          createdDate: '2018-09-29'
        }
      ],
      basicInfo: {},
      assetData: [
        {
          totlaAsset: 78999999,
          shareHolder: 222,
          stockTotal: 56454,
          stockTotalPrice: 56454,
          groupStockCount: 4343,
          groupStockPrice: 6343,
          perStockPrice: 322
        }
      ],
      stockRightData: [
        {
          type: '贡献股',
          price: '1.0'
        },
        {
          type: '贡献股',
          price: '1.0'
        },
        {
          type: '爱新股',
          price: '1.0'
        }
      ],
      form: {
        total: 1222,
        distribute: [
          {
            type: '',
            coefficient: 1.0
          }
        ]
      },
      typeList: [
        {
          label: 'kakkak',
          value: 'ssss'
        }
      ],
      dialogVisible: false,
      relationshipList: [],
      currentId: ''
    }
  },
  created() {
    this.basicInfo =  {
      address: this.$route.query.village,
      name: this.$route.query.name,
      familyNo: this.$route.query.familyNo
    }
    this.getFamilyMember()
    this.getRelationList()
  },
  methods: {
    handleEdit(flag, id) {
      if(flag == 'detail') {
        this.$router.push(`/member/edit?isEdit=${flag}&memberId=${id}&familyCount=${this.basicInfo.familyNo}`)
      }
      else {
        const fid = this.$route.query.id
        this.$router.push(`/member/edit?isEdit=${flag}&id=${fid}&memberId=${id}&familyCount=${this.basicInfo.familyNo}`)
      }
    },
    addMember() {
      const id = this.$route.query.id
      this.$router.push(`/member/edit?isEdit=addMember&id=${id}&familyCount=${this.basicInfo.familyNo}`)
    },
    goDetail() {
      this.$router.push('/member/detail')
    },
    deleteMember(item) {
      this.$confirm('确认注销？', '系统提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        const id = item.memberId
        if (item.relationship === 1 && this.tableData.length > 1) {
          this.dialogVisible = true
          this.currentId = id
        } else {
          this.cancleMember(id)
        }
      })
    },
    cancleMember(id, relationShip) {
      let params = {
        memberId: id
      }
      if(relationShip) {
        params.memberRelationships = relationShip
        params.memberId = this.currentId
      }
      cancelMember(params).then(res => {
        this.$message(
          {
            type: 'success',
            message: '操作成功！'
          }
        )
        this.dialogVisible = false
        this.getFamilyMember()
      })
    },
    makeSureCancle(id) {
      // this.$message({
      //   type: 'warning',
      //   message: '暂不能修改'
      // })
      console.log(this.form)
      let numbers = Object.keys(this.form).filter(item => !isNaN(Number(item)))
      console.log(numbers)
      let memberIds = this.tableData.map(item => item.memberId)
      let memberRelationships = numbers.map(item => {
        return {
          memberId: memberIds[item],
          relationship: this.form[item]
        }
      })
      this.cancleMember(id, memberRelationships)
    },
    getFamilyMember() {
      const id = this.$route.query.id
      familyMember({ familyId: id }).then(res => {
        this.tableData = res.data.memberInfos
      })
    },
    getRelationList(id) {
      memberRelationship({villageId: id}).then(res => {
        this.relationshipList = res.data.relationshipInfos || []
      })
    },
  }
}
</script>

<style lang="scss" scoped>
.detail-page {
  width: 100%;
  padding: 10px;
  background: rgb(235,238,242);
  min-height: calc(100vh - 50px);

  .content {
    background: #fff;
    padding: 20px;
    margin-top: 15px;
  }

  .box-card {
    margin-top: 10px;
    .clearfix {
      span {
        font-size: 14px;
        font-weight: 600;
        display: inline-block;
        margin-right: 20px;
      }
    }
  }

  .form-group {
    display: flex;
    justify-content: flex-start;
    margin-top: 30px;

    .width-200 {
      width: 200px;
    }

    .add-btn {
      margin: 0 0 0 20px;
    }
  }
  .form-item-width {
    width: 40%;
    max-width: 400px;
  }
}
</style>

<style>
  .table-header-color {
    background: rgb(245,247,250)!important;
  }
</style>
